#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

void main() {
    char name[16];
    char cmd[64];

    printf("hello give me your name:\n> ");
    read(0, name, 0x16);  // Intentional overflow (64 > 16)

    sprintf(cmd, "echo %s", name); // vulnerable to injection
    system(cmd);
}
