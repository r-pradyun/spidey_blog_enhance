#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void chall(void) {
    srand((unsigned int)time(NULL));

    // Random size between 20 and 50
    int size = 20 + rand() % 31;

    // Variable-length array on stack
    char buf[size];

    printf("Find my offset to rip.\nI will be generous and let you write as much as you want\n>");

    //Buffer overflow here
    scanf("%s",buf);

    return;
}

int main(void){
    chall();
    return 0;
}
