#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

void unbuffer_stdio(void) {
    setvbuf(stdin,  NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void win(void){
    puts("Ok, you win");
    FILE *f = fopen("flag.txt", "r");
    if (!f) {
        printf("flag.txt not found\nCreate one in current directory\n");
        exit(1);
    }
    char buf[128];
    if (fgets(buf, sizeof(buf), f)) {
        printf("%s", buf);
    }
    fclose(f);
    exit(0);
}

void chall(void){
   char buf[20];
   puts("You want to put something in buffer?\nDon't worry, I will check the length :-)\n>");
   fgets(buf,0x100,stdin);
   int n = strlen(buf);
   if (n>10){
      puts("Input too big\n");
      exit(0);
   }
   return;
}

int main(){
   unbuffer_stdio();
   chall();
   return 0;
}
