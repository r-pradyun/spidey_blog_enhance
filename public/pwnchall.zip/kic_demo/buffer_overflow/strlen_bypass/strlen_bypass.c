#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

void unbuffer_stdio(void) {
    setvbuf(stdin,  NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void handler(int sig){
   FILE *f = fopen("flag.txt", "r");
   if (!f) {
      printf("flag.txt does not exist.\nCreate a test file in current directory.\n");
      exit(1);
   }
   char buf[128];
   if (fgets(buf, sizeof(buf), f)) {
      printf("%s", buf);
   }
   fclose(f);
   exit(1);
}

void chall(void){
   char buf[20];
   printf("You want to put something in buffer?\nDon't worry, I will check the length :-)>");
   fgets(buf,0x100,stdin);
   int n = strlen(buf);
   if (n>10){
      printf("Input too big\nProcess terminated\n");
      exit(0);
   }
   return;
}

int main(){
   unbuffer_stdio();
   signal(SIGSEGV, handler);
   chall();
   return 0;
}
