#!/bin/sh
# socat pipes TCP port 1337 to stdin/stdout of challenge_bin
exec socat TCP-LISTEN:50004,reuseaddr,fork EXEC:/ctf/strlen_bypass
