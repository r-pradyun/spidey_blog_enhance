from pwn import *
from capstone import *

context.arch = 'amd64'

#----------------------------------------------------------------#
#connection logic goes here,

elf = ELF("baby_shell",checksec=False)

gdbscript='''
b*main
c
'''

if args.REMOTE:
	p = remote('10.1.75.81',5555)
elif args.GDB:
	p = gdb.debug(elf.path, gdbscript=gdbscript)
elif args.LOCAL:
	p = process(elf.path)
else:
    print("Usage:\n")
    print("Use : python attack.py LOCAL , to send your shellcode to your local Process \n")
    print("Use : python attack.py GDB , to open enter debug mode and edit the gdbscript to add and set the break points or you operation on GDB in there\n")
    print("Use: python attack.py REMOTE, to send your payload/shellcode over the remote to get the flag\n")
    print("It is adviced to find test in your local environment before attacking the remote\n")
    exit(0)


#----------------------------------------------------------------#
#write your assembly code here
assembly_code = '''

'''


shellcode = asm(assembly_code)
if len(shellcode) == 0:
    print("\nError: You did not provide code to run.\n")
    exit(1)


#----------------------------------------------------------------#
#for disassembly of your code
md = Cs(CS_ARCH_X86, CS_MODE_64)
for i in md.disasm(shellcode, 0x0):
    bytes_str = ' '.join(f"{b:02x}" for b in i.bytes)
    print(f"{bytes_str:<30}; {i.mnemonic} {i.op_str}")
#----------------------------------------------------------------#

#sending the payload here
p.recvuntil(b'Reading 0x1000 bytes from stdin.')
p.sendline(shellcode)

p.interactive()
