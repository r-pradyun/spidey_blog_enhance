#include <stdio.h>
#include <stdlib.h>

void unbuffer_stdio(void) {
    setvbuf(stdin,  NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void print_flag(void) {
    FILE *f = fopen("flag.txt", "r");
    if (!f) {
       printf("flag.txt not found.\nCreate one in current directory\n");
       exit(1);
    }
    char buf[128];
    if (fgets(buf, sizeof(buf), f)) {
        printf("%s", buf);
    }
    fclose(f);
    exit(0);
}

int main() {
    unbuffer_stdio();

    int balance = 100;
    int choice, qty;

    printf("Welcome to FlagStore v1!\n");
    printf("This challenge is simple, just buy the flag.... if you can afford it.\n");

    while (1) {
        printf("\nBalance: %d\n", balance);
        printf("1. Buy cookie (1 credit each)\n");
        printf("2. Buy FLAG (1000 credits)\n");
        printf("3. Exit\n> ");
        scanf("%d", &choice);

        if (choice == 1) {
            printf("How many cookies? ");
            scanf("%d", &qty);
            
	// BUG: negative qty increases balance
            balance -= qty;
        } else if (choice == 2) {
            if (balance >= 1000) {
                printf("Here is your flag\n");
		print_flag();
                exit(0);
            } else {
                printf("Not enough credits!\n");
            }
        } else {
            exit(0);
        }
    }
}
