#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <limits.h>

void unbuffer_stdio(void) {
    setvbuf(stdin,  NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void print_flag(void) {
    FILE *f = fopen("flag.txt", "r");
    if (!f) {
       printf("flag.txt not found.\nCreate one in current directory\n");
       exit(1);
    }
    char buf[128];
    if (fgets(buf, sizeof(buf), f)) {
        printf("%s", buf);
    }
    fclose(f);
    exit(0);
}

int main() {
    unbuffer_stdio();

    int balance = 100;  // signed 32-bit
    int choice, qty;
    const int price = 100;

    printf("Welcome to FlagStore v3!\n");

    while (1) {
        printf("\nBalance: %d\n", balance);
        printf("1. Buy cookies (%d credits each)\n", price);
        printf("2. Buy FLAG (100000 credits)\n");
        printf("3. Exit\n> ");
        scanf("%d", &choice);

        if (choice == 1) {
            printf("How many cookies? ");
            scanf("%d", &qty);

            if (qty <= 0) {
                printf("No you don't\n");
                continue;
            }

            // Safe multiplication (64-bit), to avoid v2-style overflow
            long long cost = (long long)qty * price;

            if (cost > INT_MAX) {
                printf("Quantity too large!\n");
                continue;
            }

            // BUG: subtracting cost can push signed int balance into negative overflow
            balance -= (int)cost;

        } else if (choice == 2) {
            if (balance >= 100000) {
                printf("Here is your flag\n");
                print_flag();
                exit(0);
            } else {
                printf("Not enough credits!\n");
            }
        } else {
            exit(0);
        }
    }
}
